import{D as t}from"./index-vPoYJ4wT.js";const r=()=>t.get("/front/stat/getMonthsStat"),e=()=>t.get("/front/xa/order/get/unConfirmStat");export{e as a,r as g};
