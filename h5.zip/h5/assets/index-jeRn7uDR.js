import{_ as f}from"./index-vPoYJ4wT.js";export{f as default};
